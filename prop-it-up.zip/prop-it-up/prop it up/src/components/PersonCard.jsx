import React from 'react';

const PersonCard = ({lastName,firstName,age,hairColor}) => {
    return(
        <div>
            <h2>{lastName}, {firstName}</h2>
            <h3>Age: {age}</h3>
            <h3>Hair Color: {hairColor}</h3>
        </div>
    )
}
export default PersonCard;